public class Principal {
    public static void main(String [] args){
        Window w = new Window("Fractale de Mandelbrot");
    }
}
